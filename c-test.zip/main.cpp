/*#include <iostream> 
int main()
{
int myNum=50; 
std::cout<<myNum; 

return 0; 
}*/ 

#include <iostream>

