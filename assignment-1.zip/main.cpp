/*#include <iostream>

int main()
{
    std::cout<<"Hello World"<<"\n"; 
    std::cout<<"My name is Celina"<<"\n";

    return 0;
}*/ 

/*#include <iostream>
int main()
{
    int a,b,c;
    a=b=c=13;
    std::cout<<a<<"\n";
    std::cout<<b<<"\n";
    std::cout<<c<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int leapDay=366;
    std::cout<<"There are "<<leapDay<<" days in a leap year.";
    return 0;
}*/

/*#include <iostream>
#include <string>
int main()
{
    std::string euro="€";
    std::string europe="EU";
    std::cout<<europe<<" is the abreviation of Europe and the currency that is used there is this "<<euro;
    return 0;
}*/

/*#include <iostream>
int main()
{
    bool off=false;
    bool on=true;
    std::cout<<off<<"\n";
    std::cout<<on<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int math = 98;
    int reading = 97;
    int history = 95;
    int science = 92;
    int art = 98;
    std::cout<<"I got a "<<reading<<" in reading"<<"\n";
    std::cout<<"I got a "<<math<<" in math"<<"\n";
    std::cout<<"I got a "<<history<<" in history"<<"\n";
    std::cout<<"I got a "<<science<<" in science"<<"\n";
    std::cout<<"I got a "<<art<<" in art"<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int pakistan=233691492 ;
    std::cout<<"There are "<<pakistan<<" people living in Pakistan";
    return 0;
}*/

/*#include <iostream>
int main()
{
    double nem="4.11";
    float num="4.7";
    string name="Ethan";
    std::cout<<"I am "<<nem<<" feet while my brother "<<name" is "<<num<<" feet";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int hour;
    int min;
    std::cout<<"How many hours are there?"<<"\n";
    std::cin>>hour;
    min=hour*60;
    std::cout<<"There are "<<min<<" minutes in "<<hour<<" hours.";
    return 0;
}*/

/*#include <iostream>
int main()
{
    string subj;
    int grade;
    std::cout<<"Put your favorite subject:"<<"\n";
    std::cin>>subj;
    std::cout<<"Put the grades you got in it:"<<"\n";
    std::cin>>grade;
    std::cout<<"Your favorite subject is "<<subj<<" and the grades you got in it are "<<grades<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x;
    int y;
    int sum;
    int sub;
    int mult;
    int dive;
    std::cout<<"Enter a number"<<"\n";
    std::cin>>x;
    std::cout<<"Enter another number"<<"\n";
    std::cin>>y;
    sum=x+y;
    sub=x-y;
    mult=x*y;
    dive=x/y;
    cout<<"Your sum is "<<sum<<"\n";
    cout<<"Your difference is "<<sub<<"\n";
    cout<<"Your product is "<<mult<<"\n";
    cout<<"Your quotient is"<<dive<<"\n";
    return 0;
}*/

/*#include <iostream>
#include <string>
int main()
{
    std::string greeting;
    getline(std::cin,greeting);
    std::cout<<greeting;
    return 0;
}*/

/*#include <iostream>
int main()
{
    std::string word = "imp";
    std::string werd = "oss";
    std::string wird = "ible";
    std::cout<<word.append(werd)+ ird;
    return 0;
}*/

/*#include <iostream>
int main()
{
    std::string word = "string";
    std::cout<<word.length();
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x=50;
    int y=10;
    std::cout<<max(x, y)<<"\n";
    std::cout<<min(x, y)<<"\n";
    return 0;
}*/

//assignment 2
/*#include <iostream>
#include <string>
int main()
{
    std::string text;
    std::cout<<"Type in a word:"<<"\n"
    getline(std::cin,text);
    std::cout<<text;
    return 0;
}*/

/*#include <iostream>
#include <string>
int main()
{
    std::string word = "kind";
    word[0] = 'w';
    std::cout<<word;
    return 0;
}*/

/*#include <iostream>
int main()
{
    std::cout<<log(13)<<"\n";
    std::cout<<sqrt(4.44)<<"\n";
    std::cout<<sin(73)<<"\n";
    std::cout<<cos(124)<<"\n";
    std::cout<<tan(82)<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int num=1;
    while(num > 0)
    {
        std::cout<<"Enter a number:"<<"\n";
        std::cin>>num;
        if(num > 0)
        {
            std::cout<<"You number/numbers are: "<<num<<"\n";
        }
    }
    std::cout<<"It is skipped.";
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x=1;
    int y=100;
    if(x < y)
    {
    std::cout<<"I am learning if-else conditional statements";
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    int x=89;
    int y=75;
    if(x>y)
    {
        std::cout<<"X is greater than Y";
    }
    else if (x<y)
    {
        std::cout<<"Y is greater than X";
    }
    else
    {
        std::cout<<"X and Y are equal.";
    }
    return 0;
}
*/
/*#include <iostream>
int main()
{
    int day=6;
    switch(day)
    {
    case 1:
    cout<<"Sunday";
    break;
    
    case 2:
    cout<<"Monday";
    break;
    
    case 3:
    cout<<"Tuesday";
    break;
    
    case 4:
    cout<<"Wednesday";
    break;
    
    case 5:
    cout<<"Thurday";
    break;
    
    case 6:
    cout<<"Friday";
    break;
    
    case 7:
    cout<<"Saturday";
    break;
    
    default:
    cout<<"Tomorrow";
    
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    int a=1;
    while (a<=10)
    {
       std::cout<<a<<"\t";
        ++a;
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    int c;
    int sum=0;
    do
    {
        std::cout<<"Enter a number"<<"\n";
        std::cin>>c;
        sum += c;
    }
    while (c>=1);
    std::cout<<"Your sum is "<<sum<<"\n";
    return 0;
}*/

/*#include <iostream>
int main()
{
    for(int z = 1;z < 100;++z)
    {
        std::cout<<z<<"\n";
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    for (int x=1; x <= 2;++x)
    {
        std::cout<<"Assignment day"<<"\n";
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    for (int y=1;y <= 10;y++)
    {
        std::cout<<y<<"\n";
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    int print=1;
    for(int i=1;i <=7;++i)
    {
        std::cout<<print<<"\n";
        print = print*2;
    }
    return 0;
}*/

/*#include <iostream>
int main()
{
    for (int a=1; a <= 9;++a)
    {
        for (int b=1;b <= a;++b)
        {
            std::cout<<"+";
        }
        std::cout<<"\n";
    }
    return 0;
}*/



