//Return values
/*#include <iostream>
int myNum( int x)
{
    
    return 3*x;
}
int main()
{
    std::cout<<myNum(6);
    return 0;
}*/

/*#include <iostream>
int myNum(int x, int y, int z)
{
    
    return x-y*z;
}
int main()
{
    std::cout<<myNum(6,8,9);
    return 0;
}*/

//pass array to function
/*#include <iostream>
void myFunction 
(int myNum[7])
{
    
    for(int i=1; i < 7; i++)
    {
        std::cout<<myNum[i]<<"\n";
    }
}

int main()
{
    int myNum[7]={0,9,8,7,6,5,4};
    myFunction(myNum);
    return 0;
}*/

//Recursion
/*#include <iostream>
int sum(int a)
{
    
   if(a>0)
    {
        return a+sum(a-2);
    }
    else
    {
    return 0;
    }
}
int main()
{
    int result=sum(15);
    std::cout<<result<<"\n";
    return 0;
}*/





