/*#include <iostream> 
int main() 
{

int myAge=11; 
std::cout<<"I am "<<myAge<<" years old"; 

return 0; 
} */


/*#include <iostream> 
int main() 
{

int myNum=86; 
int myNem=104; 
int myNim=87;
int sum=myNum+myNem+myNim; 
std::cout<<sum; 

return 0; 
} */

/*#include <iostream> 
int main() 
{
double myNum=8.7; 
double myNem=3.3;
double diffence=myNum-myNem; 
std::cout<<diffence;



return 0; 
}*/ 

/*#include <iostream> 
int main() 
{
int x=13,y=69,z=17; 
double a=4.6,b=5.7,c=8.2;
std::cout<<x+y+z; 
std::cout<<a+b+c;

return 0; 
}*/


/*#include <iostream> 
int main() 
{
int a,b,c=17; 
int sum=a+b+c; 
std::cout<<sum;

return 0; 
}*/


/*#include <iostream> 
int main() 
{ 
double myHeight=4.8; 
std::cout<<"My height is "<<myHeight<<" inches and feet"; 

return 0; 
} */ 


/*#include <iostream> 
int main() 
{ 
double pie=3.14; 
std::cout<<pie;


return 0; 
}*/  



/*#include <iostream> 
int main() 
{ 
char myGrade='A'; 
std::cout<<myGrade;

return 0; 
}*/  


#include <iostream> 
int main() 
{ 
int a=57; 
int b=57; 
int c=57; 
int difference=a-b-c; 
std::cout<<difference;

return 0; 
} 





























