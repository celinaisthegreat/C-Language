/*#include <iostream> 
int main()
{ 
 //outer loop 
 for(int a=12; a <= 50; ++a) 
 {
     std::cout<<"Outer"<<a<<"\n"; 
 }
//inner loop 
     for(int b=70; b <= 70; ++b) 
{
    std::cout<<"Inner"<<b<<"\n";
 }
   return 0; 
}*/

#include <iostream> 
int main()
{ 
 for(int a=0; a <= 5;  ++a) 
{
 for(int b=0; b <=5; ++b)
 std::cout<<a<<b<<"\n";
}
   return 0; 
}

