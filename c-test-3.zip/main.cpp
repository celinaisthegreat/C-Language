#include <iostream> 
int main()
{ 
    int pos=0; 
    std::cout<<"Input a number"<<"\n"; 
    std::cin>>pos; 
    while(pos>0) 
    { 
        std::cout<<"Input a second number"<<"\n"; 
        std::cin>>pos; 
    } 
      std::cout<<"Skip this number"; 
    
    return 0;
}