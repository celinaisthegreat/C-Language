#include <iostream> 
int main() 
{ 
    int x,y; 
    int sum; 
    int sub; 
    int mult; 
    int dive; 
    int mod; 
    std::cout<<"Type in a number:"; 
    std::cin>>x; 
    std::cout<<"Type in a second number:"; 
    std::cin>>y; 
    std::cout<<"Your sum is: "<<x; 
    std::cout<<"Your difference is: "<<x; 
    std::cout<<"Your product is: "<<x; 
    std::cout<<"Your quotient is: "<<x; 
    std::cout<<"Your modulus is: "<<x; 
    return 0;
}