/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string food="chicken wings";
    string*ptr=&food; 
    cout<<"food"<<"\n"; 
    cout<<&food<<"\n";;
    cout<<ptr<<"\n";;

    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string food="chicken wings";
    string*ptr=&food; 
    cout<<"food"<<"\n"; 
    cout<<ptr<<"\n";
    cout<<*ptr<<"\n";
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
int main()
{
    string food="chicken wings";
    string*ptr=&food; 
    cout<<"food"<<"\n"; 
    cout<<&food<<"\n";
    cout<<ptr<<"\n";
    *ptr="sushi";
    cout<<*ptr<<"\n";
    cout<<food<<"\n";
    return 0;
}*/

/*#include <iostream>
using namespace std;
void day()
{
    cout<<"Today is the 14th of July";
}
int main()
{
    day();
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
void function()
{
    cout<<"hi"<<"\n";
}
int main()
{
    function();
    function();
    function();
    function();
    return 0;
}*/

/*#include <iostream>
#include <string>
using namespace std;
void function(string country,int pop)
{
    cout<<"In "<<country<<" there are "<<pop<<" states"<<"\n";
}
int main()
{
    function("america",40);
    function("aMERICA",17);
    function("America",50);
    return 0;
}*/

/*#include <iostream>
using namespace std;
int sum (int a)
{
    if(a>0)
   {
    return a+sum(a-1);
   }
    else
   {
    return 0;
   }
}
int main()
{
    int result;
    result=sum(13);
    cout<<result;
    return 0;
}*/





