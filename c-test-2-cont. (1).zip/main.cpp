#include <iostream> 
int main() 
{ 
    int x,y 
    int sum; 
    int sub; 
    int mult; 
    int dive; 
    int mod; 
    std::cout<<""
    return 0;
}